import SlideNav from "./js/slide/slide.js";
import MenuMobile from "./js/menu-mobile/menu-mobile.js";

MenuMobile();

const slide = new SlideNav(".slide", ".slide-wrapper");

slide.init();
slide.addControl(".custom-controls");
